/**
 * Client-side performance monitoring utility
 * Automatically tracks and reports performance metrics
 *
 * @packageDocumentation
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var PerformanceMonitor = /** @class */ (function () {
    function PerformanceMonitor() {
        this.metrics = {
            startTime: Date.now(),
            bundleLoadTimes: [],
            errors: []
        };
        // Set app load start time
        if (typeof window !== 'undefined') {
            window.__appLoadStart = window.__appLoadStart || Date.now();
            window.performanceMetrics = this.metrics;
        }
        this.setupListeners();
    }
    PerformanceMonitor.prototype.setupListeners = function () {
        var _this = this;
        if (typeof document === 'undefined') {
            return; // SSR context
        }
        // DOM Content Loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                _this.metrics.domContentLoaded = Date.now() - _this.metrics.startTime;
                console.log('✅ DOM Content Loaded:', _this.metrics.domContentLoaded + 'ms');
            });
        }
        else {
            this.metrics.domContentLoaded = 0;
        }
        // Window Load
        if (document.readyState === 'complete') {
            this.captureLoadMetrics();
        }
        else if (typeof window !== 'undefined') {
            window.addEventListener('load', function () {
                _this.captureLoadMetrics();
            });
        }
        // Error tracking
        if (typeof window !== 'undefined') {
            window.addEventListener('error', function (e) {
                console.error('❌ Error:', e.message);
                _this.metrics.errors.push({
                    message: e.message,
                    filename: e.filename,
                    lineno: e.lineno,
                    colno: e.colno
                });
            });
        }
    };
    PerformanceMonitor.prototype.captureLoadMetrics = function () {
        this.metrics.windowLoad = Date.now() - this.metrics.startTime;
        // Performance Timing API
        if (typeof performance !== 'undefined' && performance.timing) {
            var timing = performance.timing;
            this.metrics.timing = {
                dns: timing.domainLookupEnd - timing.domainLookupStart,
                tcp: timing.connectEnd - timing.connectStart,
                ttfb: timing.responseStart - timing.navigationStart,
                domProcessing: timing.domComplete - timing.domLoading,
                pageLoad: timing.loadEventEnd - timing.navigationStart,
                domContentLoaded: timing.domContentLoadedEventEnd - timing.navigationStart,
                totalLoadTime: Date.now() - (typeof window !== 'undefined' && window.__appLoadStart ? window.__appLoadStart : this.metrics.startTime)
            };
            console.log('📊 Performance Metrics:');
            console.log('  DNS Lookup:', this.metrics.timing.dns + 'ms');
            console.log('  TCP Connection:', this.metrics.timing.tcp + 'ms');
            console.log('  Time to First Byte:', this.metrics.timing.ttfb + 'ms');
            console.log('  DOM Processing:', this.metrics.timing.domProcessing + 'ms');
            console.log('  DOM Content Loaded:', this.metrics.timing.domContentLoaded + 'ms');
            console.log('  Page Load:', this.metrics.timing.pageLoad + 'ms');
            console.log('  Total Load Time:', this.metrics.timing.totalLoadTime + 'ms');
        }
        // Paint Metrics
        this.capturePaintMetrics();
        // Resource Timing
        this.captureResourceMetrics();
        // Largest Contentful Paint
        this.captureLCP();
        // First Input Delay
        this.captureFID();
        // Export instructions
        console.log('\n💾 To export metrics, run: copy(JSON.stringify(window.performanceMetrics, null, 2))');
    };
    PerformanceMonitor.prototype.capturePaintMetrics = function () {
        var _this = this;
        if (typeof performance === 'undefined' || !performance.getEntriesByType) {
            return;
        }
        var paintEntries = performance.getEntriesByType('paint');
        paintEntries.forEach(function (entry) {
            console.log('🎨', entry.name + ':', Math.round(entry.startTime) + 'ms');
            if (entry.name === 'first-contentful-paint') {
                _this.metrics.firstContentfulPaint = Math.round(entry.startTime);
            }
        });
    };
    PerformanceMonitor.prototype.captureResourceMetrics = function () {
        var _this = this;
        if (typeof performance === 'undefined' || !performance.getEntriesByType) {
            return;
        }
        var resources = performance.getEntriesByType('resource');
        var jsResources = resources.filter(function (r) {
            return r.name.endsWith('.js') || r.name.includes('.bundle.');
        });
        console.log('\n📦 JavaScript Bundle Load Times:');
        jsResources.forEach(function (resource) {
            var bundleName = resource.name.split('/').pop() || resource.name;
            var loadTime = Math.round(resource.duration);
            var size = resource.transferSize || 'cached';
            console.log('  ' + bundleName + ':', loadTime + 'ms', '(' + (size !== 'cached' ? (size / 1024).toFixed(2) + ' KB' : 'cached') + ')');
            _this.metrics.bundleLoadTimes.push({
                name: bundleName,
                duration: loadTime,
                size: size
            });
        });
        // Calculate total bundle size
        var totalSize = jsResources.reduce(function (acc, r) { return acc + (r.transferSize || 0); }, 0);
        console.log('\n📊 Total JS Bundle Size:', (totalSize / 1024).toFixed(2) + ' KB');
        console.log('📊 Total JS Resources:', jsResources.length);
        this.metrics.totalBundleSize = totalSize;
        this.metrics.totalBundleCount = jsResources.length;
    };
    PerformanceMonitor.prototype.captureLCP = function () {
        var _this = this;
        if (typeof PerformanceObserver === 'undefined' ||
            !PerformanceObserver.supportedEntryTypes ||
            !PerformanceObserver.supportedEntryTypes.includes('largest-contentful-paint')) {
            return;
        }
        try {
            var observer = new PerformanceObserver(function (list) {
                var entries = list.getEntries();
                var lastEntry = entries[entries.length - 1];
                if (lastEntry) {
                    console.log('🖼️ Largest Contentful Paint:', Math.round(lastEntry.startTime) + 'ms');
                    _this.metrics.largestContentfulPaint = Math.round(lastEntry.startTime);
                }
            });
            observer.observe({ entryTypes: ['largest-contentful-paint'] });
        }
        catch (e) {
            console.warn('LCP observation failed:', e);
        }
    };
    PerformanceMonitor.prototype.captureFID = function () {
        var _this = this;
        if (typeof PerformanceObserver === 'undefined' ||
            !PerformanceObserver.supportedEntryTypes ||
            !PerformanceObserver.supportedEntryTypes.includes('first-input')) {
            return;
        }
        try {
            var observer = new PerformanceObserver(function (list) {
                var entries = list.getEntries();
                entries.forEach(function (entry) {
                    var fid = Math.round(entry.processingStart - entry.startTime);
                    console.log('⚡ First Input Delay:', fid + 'ms');
                    _this.metrics.firstInputDelay = fid;
                });
            });
            observer.observe({ entryTypes: ['first-input'] });
        }
        catch (e) {
            console.warn('FID observation failed:', e);
        }
    };
    PerformanceMonitor.prototype.getMetrics = function () {
        return this.metrics;
    };
    PerformanceMonitor.prototype.exportMetrics = function () {
        return JSON.stringify(this.metrics, null, 2);
    };
    PerformanceMonitor.prototype.sendMetrics = function () {
        return __awaiter(this, arguments, void 0, function (endpoint) {
            var error_1;
            if (endpoint === void 0) { endpoint = '/api/performance-metrics'; }
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, fetch(endpoint, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: this.exportMetrics()
                            })];
                    case 1:
                        _a.sent();
                        console.log('✅ Performance metrics sent to server');
                        return [3 /*break*/, 3];
                    case 2:
                        error_1 = _a.sent();
                        console.error('❌ Failed to send performance metrics:', error_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    return PerformanceMonitor;
}());
export { PerformanceMonitor };
// Auto-initialize singleton for browser context
var defaultMonitor = null;
if (typeof window !== 'undefined') {
    defaultMonitor = new PerformanceMonitor();
}
// Export server-side utilities
export { generatePerfMonitorScript, injectPerfMonitorScript, extractNonce } from './server-utils';
export default defaultMonitor;
//# sourceMappingURL=index.js.map