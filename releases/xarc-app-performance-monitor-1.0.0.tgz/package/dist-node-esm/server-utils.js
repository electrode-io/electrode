/**
 * Server-side utilities for injecting performance monitoring scripts
 * @packageDocumentation
 */
/**
 * Generates the inline performance monitoring initialization script
 * This script must run before any other scripts to accurately track load times
 *
 * @param options - Configuration options for script generation
 * @returns The complete script tag as a string
 */
export function generatePerfMonitorScript(options) {
    if (options === void 0) { options = {}; }
    var _a = options.nonce, nonce = _a === void 0 ? '' : _a, _b = options.minify, minify = _b === void 0 ? process.env.NODE_ENV === 'production' : _b;
    var nonceAttr = nonce ? " nonce=\"".concat(nonce, "\"") : '';
    // This initialization script sets up the performance tracking globals
    // before any bundles load, ensuring we capture accurate timing data
    var script = minify
        ? "(function(){window.__appLoadStart=Date.now();window.performanceMetrics={startTime:Date.now(),scriptLoadTimes:{},bundleLoadTimes:[],errors:[]};})();"
        : "(function() {\n  window.__appLoadStart = Date.now();\n  window.performanceMetrics = {\n    startTime: Date.now(),\n    scriptLoadTimes: {},\n    bundleLoadTimes: [],\n    errors: []\n  };\n})();";
    return "<script".concat(nonceAttr, ">\n// Performance monitoring - tracks app load time\n").concat(script, "\n</script>");
}
/**
 * Injects the performance monitoring script into HTML string
 * Automatically extracts nonce from existing script tags if not provided
 *
 * @param html - The HTML string to inject the script into
 * @param options - Configuration options (nonce will be auto-detected if not provided)
 * @returns The modified HTML with performance monitoring script injected
 */
export function injectPerfMonitorScript(html, options) {
    if (options === void 0) { options = {}; }
    // Auto-detect nonce from first script tag if not explicitly provided
    var nonce = options.nonce, minify = options.minify;
    if (!nonce) {
        var nonceMatch = html.match(/nonce="([^"]+)"/);
        nonce = nonceMatch ? nonceMatch[1] : '';
    }
    var perfMonitorScript = generatePerfMonitorScript({ nonce: nonce, minify: minify });
    // Inject at the beginning of <head> to ensure it runs first
    if (html.includes('<head>')) {
        return html.replace('<head>', "<head>".concat(perfMonitorScript));
    }
    // Fallback: inject at the beginning of the HTML if no <head> tag found
    return perfMonitorScript + html;
}
/**
 * Extracts nonce value from HTML string
 * Useful when you need to get the nonce separately
 *
 * @param html - The HTML string to extract nonce from
 * @returns The nonce value or empty string if not found
 */
export function extractNonce(html) {
    var nonceMatch = html.match(/nonce="([^"]+)"/);
    return nonceMatch ? nonceMatch[1] : '';
}
//# sourceMappingURL=server-utils.js.map