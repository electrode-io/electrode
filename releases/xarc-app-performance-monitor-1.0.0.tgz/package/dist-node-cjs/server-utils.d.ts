/**
 * Server-side utilities for injecting performance monitoring scripts
 * @packageDocumentation
 */
export interface InjectScriptOptions {
    /**
     * CSP nonce for script tag (required for Content Security Policy compliance)
     */
    nonce?: string;
    /**
     * Whether to minify the injected script (default: true in production)
     */
    minify?: boolean;
}
/**
 * Generates the inline performance monitoring initialization script
 * This script must run before any other scripts to accurately track load times
 *
 * @param options - Configuration options for script generation
 * @returns The complete script tag as a string
 */
export declare function generatePerfMonitorScript(options?: InjectScriptOptions): string;
/**
 * Injects the performance monitoring script into HTML string
 * Automatically extracts nonce from existing script tags if not provided
 *
 * @param html - The HTML string to inject the script into
 * @param options - Configuration options (nonce will be auto-detected if not provided)
 * @returns The modified HTML with performance monitoring script injected
 */
export declare function injectPerfMonitorScript(html: string, options?: InjectScriptOptions): string;
/**
 * Extracts nonce value from HTML string
 * Useful when you need to get the nonce separately
 *
 * @param html - The HTML string to extract nonce from
 * @returns The nonce value or empty string if not found
 */
export declare function extractNonce(html: string): string;
