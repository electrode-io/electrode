/**
 * Client-side performance monitoring utility
 * Automatically tracks and reports performance metrics
 *
 * @packageDocumentation
 */
export interface PerformanceMetrics {
    startTime: number;
    domContentLoaded?: number;
    windowLoad?: number;
    firstContentfulPaint?: number;
    largestContentfulPaint?: number;
    firstInputDelay?: number;
    bundleLoadTimes: Array<{
        name: string;
        duration: number;
        size: number | string;
    }>;
    totalBundleSize?: number;
    totalBundleCount?: number;
    timing?: {
        dns: number;
        tcp: number;
        ttfb: number;
        domProcessing: number;
        pageLoad: number;
        domContentLoaded: number;
        totalLoadTime: number;
    };
    errors: Array<{
        message: string;
        filename?: string;
        lineno?: number;
        colno?: number;
    }>;
}
declare global {
    interface Window {
        __appLoadStart?: number;
        performanceMetrics?: PerformanceMetrics;
    }
}
export declare class PerformanceMonitor {
    private metrics;
    constructor();
    private setupListeners;
    private captureLoadMetrics;
    private capturePaintMetrics;
    private captureResourceMetrics;
    private captureLCP;
    private captureFID;
    getMetrics(): PerformanceMetrics;
    exportMetrics(): string;
    sendMetrics(endpoint?: string): Promise<void>;
}
declare let defaultMonitor: PerformanceMonitor | null;
export { generatePerfMonitorScript, injectPerfMonitorScript, extractNonce, type InjectScriptOptions } from './server-utils';
export default defaultMonitor;
